package com.hutchinsonports.application.demo.app.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.net.URI;
import java.time.LocalDateTime;

@Entity
@Table(name = "face_to_face_courses")
public class FaceToFaceCourse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty(message = "El nombre es obligatorio.")
    @Size(min = 1, max = 20, message = "El nombre debe contener entre 1 y 20 caracteres.")
    @Column(name = "name", length = 20, nullable = false)
    private String name;

    @Size(max = 200, message = "La observación debe tener un máximo de 200 caracteres.")
    @NotEmpty(message = "El campo no puede quedar vacio.")
    @Column(name = "observation", length = 200)
    private String observation;

    @NotNull(message = "La fecha es obligatoria.")
    @Column(name = "date", nullable = false)
    private LocalDateTime date;

    @NotEmpty(message = "El estado es obligatorio.")
    @Size(max = 10, message = "El estado debe tener un máximo de 10 caracteres.")
    @Column(name = "status", length = 10, nullable = false)
    private String status;

    @Size(max = 20, message = "El nombre de la persona que impartió el curso debe tener un máximo de 20 caracteres.")
    @NotEmpty(message = "Ingrese el nombre de quien impartio el curso.")
    @Column(name = "person_who_taught_it", length = 20)
    private String personWhoTaughtIt;

    @Lob
    @NotEmpty(message = "El archivo esta vacio.")
    @Column(name = "file", columnDefinition="LONGBLOB")
    private byte[] file;

    @Column(name = "create_at", nullable = false)
    private LocalDateTime createAt;


    @Column(name = "create_users", length = 45, nullable = false)
    private String createUsers;

    @Column(name = "update_at")
    private LocalDateTime updateAt;

    @Column(name = "update_users", length = 45)
    private String updateUsers;
    

  
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "userID", nullable = false)
    @NotNull(message = "El usuario no puede ser nulo")
    private User user;

    // Constructor parametrizado
    public FaceToFaceCourse(String name, String observation, LocalDateTime date, String status, String personWhoTaughtIt, byte[] file, LocalDateTime createAt, String createUsers, LocalDateTime updateAt, String updateUsers, User user) {
        this.name = name;
        this.observation = observation;
        this.date = date;
        this.status = status;
        this.personWhoTaughtIt = personWhoTaughtIt;
        this.file = file;
        this.createAt = createAt;
        this.createUsers = createUsers;
        this.updateAt = updateAt;
        this.updateUsers = updateUsers;
        this.user = user;
    }

    public FaceToFaceCourse() {}

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPersonWhoTaughtIt() {
        return personWhoTaughtIt;
    }

    public void setPersonWhoTaughtIt(String personWhoTaughtIt) {
        this.personWhoTaughtIt = personWhoTaughtIt;
    }

    public byte[] getFile() {
        return file;
    }

    public void setFile(byte[] file) {
        this.file = file;
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(LocalDateTime createAt) {
        this.createAt = createAt;
    }

    public String getCreateUsers() {
        return createUsers;
    }

    public void setCreateUsers(String createUsers) {
        this.createUsers = createUsers;
    }

    public LocalDateTime getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(LocalDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public String getUpdateUsers() {
        return updateUsers;
    }

    public void setUpdateUsers(String updateUsers) {
        this.updateUsers = updateUsers;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

	public URI getFilePath() {
		// TODO Auto-generated method stub
		return null;
	}



	public void setFilePath(String filePath) {
		// TODO Auto-generated method stub
		
	}
}
