package com.hutchinsonports.application.demo.app.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.hutchinsonports.application.demo.app.domain.Department;
import com.hutchinsonports.application.demo.app.service.DepartmentService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;

@Controller
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    // Listar departamentos
    @GetMapping("/departament")
    public String listDepartments(Model model,
                                  @RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "5") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Department> departments = departmentService.findAll(pageable);
        model.addAttribute("departments", departments.getContent());
        model.addAttribute("totalPages", departments.getTotalPages());
        model.addAttribute("currentPage", page);

        // Obtener el nombre del usuario actual
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }
        model.addAttribute("username", username);

        return "departament";
    }

    // Mostrar formulario para agregar un nuevo departamento
    @GetMapping("/registerDepartment")
    public String showAddDepartmentForm(Model model) {
        Department department = new Department();

        // Obtener el nombre del usuario autenticado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }

        // Establecer el nombre del usuario autenticado y la fecha actual
        department.setCreateUsers(username);
        department.setUpdateUsers(username);
        department.setCreateAt(LocalDateTime.now());
        department.setUpdateAt(LocalDateTime.now());

        model.addAttribute("department", department);
        return "registerDepartment";
    }

    @PostMapping("/registerDepartment")
    public String registerDepartment(@Valid @ModelAttribute("department") Department department,
                                     BindingResult result,
                                     Model model,
                                     RedirectAttributes redirectAttributes) {
        // Verificar si ya existe un departamento con el mismo nombre
        if (departmentService.existsByName(department.getName())) {
            redirectAttributes.addFlashAttribute("errorMessage", "El departamento ya existe.");
            return "redirect:/registerDepartment";
        }

        // Verificar si hay errores en el formulario
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Estamos teniendo problemas, regresa más tarde");
            return "registerDepartment";
        }

        // Guardar el departamento
        departmentService.save(department);

        // Redirigir a la página de departamentos con un mensaje de éxito
        redirectAttributes.addFlashAttribute("successMessage", "El departamento ha sido registrado correctamente");
        return "redirect:/departament";
    }


    // Mostrar formulario para editar un departamento
    @GetMapping("/editDepartment")
    public String showEditDepartmentForm(@RequestParam("id") Long id, Model model, RedirectAttributes redirectAttributes) {
        Department department = departmentService.findById(id).orElse(null);
        if (department != null) {

            // Obtener el nombre del usuario autenticado
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = null;
            if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
                UserDetails userDetails = (UserDetails) authentication.getPrincipal();
                username = userDetails.getUsername();
            }
            department.setUpdateUsers(username);
            department.setUpdateAt(LocalDateTime.now());

            model.addAttribute("department", department);
            return "editDepartment";
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Departamento no encontrado");
            return "redirect:/departament";
        }
    }

    // Actualizar departamento
    @PostMapping("/editDepartment")
    public String updateDepartment(@Valid @ModelAttribute("department") Department department,
                                   BindingResult result,
                                   Model model,
                                   RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "editDepartment";
        }

        if (department.getId() == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "El ID del departamento no puede ser nulo.");
            return "redirect:/departaments";
        }

        Department departamentoActualizado = departmentService.findById(department.getId()).orElse(null);
        if (departamentoActualizado != null) {
            departamentoActualizado.setName(department.getName());
            departamentoActualizado.setInCharge(department.getInCharge());
            departamentoActualizado.setStatus(department.getStatus());
            departamentoActualizado.setUpdateAt(LocalDateTime.now());
            departamentoActualizado.setUpdateUsers(SecurityContextHolder.getContext().getAuthentication().getName());

            departmentService.save(departamentoActualizado);
            redirectAttributes.addFlashAttribute("successMessage", "Departamento actualizado con éxito");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "No se encontró el departamento a actualizar");
        }

        return "redirect:/departament";
    }

    // Eliminar departamento
    @PostMapping("/eliminarDepartamento")
    public String deleteDepartment(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        Department department = departmentService.findById(id).orElse(null);
        if (department != null) {
            departmentService.deleteDepartment(department);
            redirectAttributes.addFlashAttribute("successMessage", "El departamento ha sido eliminado correctamente");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "El departamento no ha sido encontrado");
        }
        return "redirect:/departament";
    }
}
