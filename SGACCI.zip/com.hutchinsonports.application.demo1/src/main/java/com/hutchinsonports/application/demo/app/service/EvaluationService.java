package com.hutchinsonports.application.demo.app.service;

import java.util.List;

import com.hutchinsonports.application.demo.app.domain.User;

public interface EvaluationService {
    User findById(Long id);
    List<User> findAll();
    User save(User user);
    void deleteById(Long id);
}

