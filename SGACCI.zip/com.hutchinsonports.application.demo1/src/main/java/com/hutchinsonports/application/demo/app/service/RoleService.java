package com.hutchinsonports.application.demo.app.service;

import com.hutchinsonports.application.demo.app.domain.Role;
import com.hutchinsonports.application.demo.app.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    // Obtener todos los roles
    public List<Role> findAll() {
        return roleRepository.findAll();
    }

    // Encontrar un rol por ID


    // Guardar o actualizar un rol
    public Role save(Role role) {
        return roleRepository.save(role);
    }

    // Eliminar un rol por ID
    public void delete(Long id) {
        roleRepository.deleteById(id);
    }

	public Page<Role> findAll(Pageable pageable) {
        return roleRepository.findAll(pageable);
    
	}
	
	public Role findById(Long id) {
	    return roleRepository.findById(id).orElse(null);
	}

	public boolean existsByrolName(String rolName) {
		return roleRepository.existsByRolName(rolName);
	}

    
}
