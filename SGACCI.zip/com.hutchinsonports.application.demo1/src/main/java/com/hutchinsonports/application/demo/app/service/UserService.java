package com.hutchinsonports.application.demo.app.service;

import com.hutchinsonports.application.demo.app.domain.User;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {
    List<User> findAll();
    Optional<User> findById(Long id);
    Optional<User> findByUsersName(String usersName);  
    void save(User user);
    void deleteById(Long id);
    Optional<User> getUserById(Long id);
    void deleteUser(User user);
    Optional<User> findCurrentUser();
    boolean existsByUsersName(String usersName);
    boolean existsByEmail(String email);
    boolean existsByFullName(String fullName);
	Page<User> findAll(Pageable pageable);
	void registerUser(String username, String password, String email);
    void updatePasswords();
    void assignRoleToUser(Long userId, Long roleId);
    

}
