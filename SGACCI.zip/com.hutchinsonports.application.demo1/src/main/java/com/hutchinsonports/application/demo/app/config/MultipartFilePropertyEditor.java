package com.hutchinsonports.application.demo.app.config;

import java.beans.PropertyEditorSupport;
import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;


public class MultipartFilePropertyEditor extends PropertyEditorSupport {

   

    @Override
    public void setValue(Object value) {
        if (value instanceof MultipartFile) {
            try {
                this.setValue(((MultipartFile) value).getBytes());
            } catch (IOException e) {
                throw new RuntimeException("Error al convertir MultipartFile a byte[]", e);
            }
        } else {
            super.setValue(value);
        }
    }
}

/*es una implementación de PropertyEditorSupport que se utiliza para convertir un objeto MultipartFile
 *  a un array de bytes (byte[]). Los PropertyEditor se usan en Spring y JavaBeans 
 * para convertir propiedades entre diferentes tipos, especialmente cuando se manejan formularios web. */
 