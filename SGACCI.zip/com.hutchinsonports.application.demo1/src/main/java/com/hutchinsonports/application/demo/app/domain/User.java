package com.hutchinsonports.application.demo.app.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;



@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty(message = "El nombre de usuario es obligatorio.")
    @Size(min = 3, max = 25, message = "El nombre de usuario debe contener entre 3 y 20 caracteres.")
    @Column(name = "users_name", length = 25, nullable = false)
    private String usersName;

    @NotEmpty(message = "La contraseña es obligatoria.")
    @Size(min = 8, max = 100, message = "La contraseña debe contener entre 8 y 100 caracteres.")
    @Column(name = "password", length = 100, nullable = false)
    private String password;

    @NotEmpty(message = "El correo electrónico es obligatorio.")
    @Email(message = "El correo electrónico debe ser válido.")
    @Size(max = 45, message = "El correo electrónico debe tener un máximo de 45 caracteres.")
    @Column(name = "email", length = 45, nullable = false)
    private String email;

    @Size(max = 50, message = "El nombre completo debe tener un máximo de 50 caracteres.")
    @NotEmpty(message = "El nombre de usuario es obligatorio.")
    @Column(name = "full_name", length = 50)
    private String fullName;

    @Column(name = "status", length = 45, nullable = false)
    private String status;

    @Column(name = "create_at", nullable = false)
    private LocalDateTime createAt;


    @Column(name = "create_users", length = 45, nullable = false)
    private String createUsers;

    @Column(name = "update_at")
    private LocalDateTime updateAt;

    @Column(name = "update_users", length = 45)
    private String updateUsers;
    
    
    @Transient
    private String passwordConfirm;

    @ManyToOne
    @JoinColumn(name = "departments_id", referencedColumnName = "id")
    private Department departamentos;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "user_role",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();


    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Course> courses = new HashSet<>();
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<FaceToFaceCourse> faceToFaceCourses = new HashSet<>();

    // Constructor por defecto y parametrizado
    public User() {
    }

    public User(String usersName, String password, String email, String fullName, String status, LocalDateTime createAt, String createUsers, LocalDateTime updateAt, String updateUsers, Department department, Set<Role> roles) {
        this.usersName = usersName;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.status = status;
        this.createAt = createAt;
        this.createUsers = createUsers;
        this.updateAt = updateAt;
        this.updateUsers = updateUsers;
        this.departamentos = department;
        this.roles = roles;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsersName() {
        return usersName;
    }

    public void setUsersName(String usersName) {
        this.usersName = usersName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }
  
    public void setCreateAt(LocalDateTime createAt) {
        this.createAt = createAt;
    }

    public String getCreateUsers() {
        return createUsers;
    }

    public void setCreateUsers(String createUsers) {
        this.createUsers = createUsers;
    }

    public LocalDateTime getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(LocalDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public String getUpdateUsers() {
        return updateUsers;
    }

    public void setUpdateUsers(String updateUsers) {
        this.updateUsers = updateUsers;
    }

    public Department getDepartment() {
        return departamentos;
    }

    public void setDepartment(Department department) {
        this.departamentos = department;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public Set<Course> getCourses() {
        return courses;
    }

    public void setCourses(Set<Course> courses) {
        this.courses = courses;
    }

    public Set<FaceToFaceCourse> getFaceToFaceCourses() {
        return faceToFaceCourses;
    }

    public void setFaceToFaceCourses(Set<FaceToFaceCourse> faceToFaceCourses) {
        this.faceToFaceCourses = faceToFaceCourses;
    }

    public String getPasswordConfirm() {
        return passwordConfirm;
    }

    public void setPasswordConfirm(String passwordConfirm) {
        this.passwordConfirm = passwordConfirm;
    }

	public User orElse(Object object) {
		// TODO Auto-generated method stub
		return null;
	}

	public User orElseThrow(Object object) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setRole(Role byId) {
		// TODO Auto-generated method stub
		
	}




}
