package com.hutchinsonports.application.demo.app.domain;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "departamentos")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty(message = "El nombre del departamento es obligatorio.")
    @Size(max = 20, message = "El nombre del departamento debe tener un máximo de 20 caracteres.")
    @Column(name = "name", length = 20, nullable = false)
    private String name;

    @Size(max = 20, message = "El nombre del encargado debe tener un máximo de 20 caracteres.")
    @NotEmpty(message = "El campo no puede quedar vacio.")
    @Column(name = "in_charge", length = 20)
    private String inCharge;

    @NotEmpty(message = "El estado es obligatorio.")
    @Size(max = 10, message = "El estado debe tener un máximo de 10 caracteres.")
    @Column(name = "status", length = 10, nullable = false)
    private String status;

    @Column(name = "create_at", nullable = false)
    private LocalDateTime createAt;


    @Column(name = "create_users", length = 45, nullable = false)
    private String createUsers;

    @Column(name = "update_at")
    private LocalDateTime updateAt;

    @Column(name = "update_users", length = 45)
    private String updateUsers;
    

  
    @OneToMany(mappedBy = "departamentos", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<User> users = new HashSet<>();

    // Constructor por defecto y parametrizado
    public Department() {
    }

    public Department(String name, String inCharge, String status, LocalDateTime createAt, String createUsers, LocalDateTime updateAt, String updateUsers) {
        this.name = name;
        this.inCharge = inCharge;
        this.status = status;
        this.createAt = createAt;
        this.createUsers = createUsers;
        this.updateAt = updateAt;
        this.updateUsers = updateUsers;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInCharge() {
        return inCharge;
    }

    public void setInCharge(String inCharge) {
        this.inCharge = inCharge;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(LocalDateTime createAt) {
        this.createAt = createAt;
    }

    public String getCreateUsers() {
        return createUsers;
    }

    public void setCreateUsers(String createUsers) {
        this.createUsers = createUsers;
    }

    public LocalDateTime getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(LocalDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public String getUpdateUsers() {
        return updateUsers;
    }

    public void setUpdateUsers(String updateUsers) {
        this.updateUsers = updateUsers;
    }

    public Set<User> getUsers() {
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }
}
