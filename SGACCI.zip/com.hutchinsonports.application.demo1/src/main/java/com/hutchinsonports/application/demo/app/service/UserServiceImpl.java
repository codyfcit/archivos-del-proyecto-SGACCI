package com.hutchinsonports.application.demo.app.service;

import com.hutchinsonports.application.demo.app.Exception.UserAlreadyExistsException;
import com.hutchinsonports.application.demo.app.domain.Role;
import com.hutchinsonports.application.demo.app.domain.User;
import com.hutchinsonports.application.demo.app.repository.RoleRepository;
import com.hutchinsonports.application.demo.app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Override
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public Optional<User> findByUsersName(String usersName) {
        return userRepository.findByUsersName(usersName);
    }

    @Override
    public void save(User user) {
        userRepository.save(user);
    }

    @Override
    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }

    @Override
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public void deleteUser(User user) {
        userRepository.delete(user);
    }



	public Page<User> findAll(Pageable pageable) {
        return userRepository.findAll(pageable);
    
	}


    public boolean existsByUsersName(String usersName) {
        return userRepository.existsByUsersName(usersName);
    }

    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }

    public boolean existsByFullName(String fullName) {
        return userRepository.existsByFullName(fullName);
    }

    public void registerUser(String username, String password, String email) {
        if (existsByUsersName(username)) {
            throw new UserAlreadyExistsException("Username already exists");
        }
        if (existsByEmail(email)) {
            throw new UserAlreadyExistsException("Email already exists");
        }
        User user = new User();
        user.setUsersName(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setEmail(email);
        userRepository.save(user);
    }

    @Override
    public Optional<User> findCurrentUser() {
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userRepository.findByUsersName(userDetails.getUsername());
    }

    @Override
    public void updatePasswords() {
        List<User> users = userRepository.findAll();
        for (User user : users) {
            if (!user.getPassword().startsWith("$2a$")) { // Verifica si la contraseña no está codificada en BCrypt
                user.setPassword(passwordEncoder.encode(user.getPassword()));
                userRepository.save(user);
            }
        }
    }
    @Override
    public void assignRoleToUser(Long userId, Long roleId) {
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<Role> roleOptional = roleRepository.findById(roleId);

        if (userOptional.isPresent() && roleOptional.isPresent()) {
            User user = userOptional.get();
            Role role = roleOptional.get();
            user.getRoles().add(role);
            userRepository.save(user);
        } else {
            throw new RuntimeException("Usuario o Rol no encontrado");
        }
 
    }
    
    public void asignarUsuarioARol(Long rolId, Long usuarioId) {
        Role rol = roleRepository.findById(rolId)
                                .orElseThrow(() -> new IllegalArgumentException("Rol no encontrado"));

        User usuario = userRepository.findById(usuarioId)
                                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        rol.getUsers().add(usuario);
        roleRepository.save(rol);
    }
}
