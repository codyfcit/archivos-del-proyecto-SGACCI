package com.hutchinsonports.application.demo.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.web.multipart.MultipartFile;


@Configuration
public class AppConfig {

    @Bean
    public Converter<MultipartFile, byte[]> multipartFileToByteArrayConverter() {
        return new MultipartFileToByteArrayConverter();
    }
}

/*configuración de Spring donde se registra un Converter que 
 *  convierte objetos de tipo MultipartFile a arrays de bytes (byte[])
 */
