package com.hutchinsonports.application.demo.app.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hutchinsonports.application.demo.app.domain.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsersName(String usersName);

	boolean existsByUsersName(String usersName);
	boolean existsByEmail(String email);
	boolean existsByFullName(String fullName);
}
