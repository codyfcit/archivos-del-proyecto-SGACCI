package com.hutchinsonports.application.demo.app.controller;

import com.hutchinsonports.application.demo.app.domain.FaceToFaceCourse;
import com.hutchinsonports.application.demo.app.domain.User;
import com.hutchinsonports.application.demo.app.service.CourseFaceToFaceService;
import com.hutchinsonports.application.demo.app.service.UserService;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.io.IOException;
import java.util.List;

@Controller
public class CurseFaceToFaceController {

    @Autowired
    private CourseFaceToFaceService service;
    
    @Autowired
    private UserService userService;

    @GetMapping("/courseFaceToFace")
    public String listCourses(Model model, 
            @RequestParam(defaultValue = "0") int page, 
            @RequestParam(defaultValue = "5") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<FaceToFaceCourse> coursePage = service.findAll(pageable);
        
        model.addAttribute("courses", coursePage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", coursePage.getTotalPages());
        // Obtener el nombre del usuario actual
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }
        model.addAttribute("username", username);

        return "courseFaceToFace";
    }

    @GetMapping("/registerCurseFaceToFace")
    public String createForm(Model model) {
        model.addAttribute("course", new FaceToFaceCourse());

        // Obtener la lista de usuarios
        List<User> users = userService.findAll();
        model.addAttribute("users", users);

        // Retornar la vista para registrar el curso
        return "registerCurseFaceToFace"; 
    }

    @PostMapping("/registerCurseFaceToFace")
    public String saveCourse(@Valid @ModelAttribute("course") FaceToFaceCourse course,
                             BindingResult result, Model model,
                             @RequestParam("file") MultipartFile file,
                             RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("users", userService.findAll());
            return "registerCurseFaceToFace";
        }

        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "El archivo está vacío.");
            return "redirect:/registerCourseFaceToFace";
        }

        try {
            User user = userService.findById(course.getUser().getId()).orElse(null);
            if (user == null) {
                redirectAttributes.addFlashAttribute("errorMessage", "Usuario no encontrado.");
                model.addAttribute("users", userService.findAll());
                return "registerCurseFaceToFace";
            }

            course.setFile(file.getBytes());
            course.setUser(user); 
            service.save(course);
            redirectAttributes.addFlashAttribute("successMessage", "Curso presencial registrado exitosamente.");
            return "redirect:/courseFaceToFace";
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error al subir el archivo: " + e.getMessage());
            return "redirect:/registerCurseFaceToFace";
        }
    }

    @GetMapping("/editCoursFaceToFace")
    public String showEditForm(@RequestParam("id") Long id, Model model, RedirectAttributes redirectAttributes) {
        FaceToFaceCourse course = service.findById(id).orElse(null);
        if (course != null) {
            model.addAttribute("course", course);
            model.addAttribute("users", userService.findAll()); // Añade los usuarios al modelo
            return "editCoursFaceToFace"; 
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Curso no encontrado");
            return "redirect:/courseFaceToFace";
        }
    }

    @PostMapping("/editCoursFaceToFace")
    public String updateCourse(@PathVariable("id") Long id,
                               @Valid @ModelAttribute("course") FaceToFaceCourse course,
                               BindingResult result,
                               @RequestParam("file") MultipartFile file) throws IOException {
        if (result.hasErrors()) {
            return "editCoursFaceToFace";
        }

        FaceToFaceCourse existingCourse = service.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid course Id:" + id));
        
        if (!file.isEmpty()) {
            existingCourse.setFile(file.getBytes());
        }

        existingCourse.setName(course.getName());
        existingCourse.setObservation(course.getObservation());
        existingCourse.setDate(course.getDate());
        existingCourse.setStatus(course.getStatus());
        existingCourse.setPersonWhoTaughtIt(course.getPersonWhoTaughtIt());
        existingCourse.setUpdateAt(course.getUpdateAt());
        existingCourse.setUpdateUsers(course.getUpdateUsers());

        service.save(existingCourse);
        return "redirect:/courseFaceToFace";
    }

    @GetMapping("/viewFile")
    public ResponseEntity<byte[]> viewFile(@RequestParam("id") Long id) {
        FaceToFaceCourse course = service.findById(id).orElse(null);
        if (course != null && course.getFile() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF); // Cambiar a APPLICATION_PDF si se trata de PDFs
            headers.setContentDisposition(ContentDisposition.builder("inline")
                .filename(course.getName() + ".pdf") // Usar el nombre del curso para el archivo
                .build());
            return new ResponseEntity<>(course.getFile(), headers, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/downloadFile")
    public ResponseEntity<byte[]> downloadFile(@RequestParam("id") Long id) {
        FaceToFaceCourse course = service.findById(id).orElse(null);
        if (course != null && course.getFile() != null) {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF); // Cambiar a APPLICATION_PDF si se trata de PDFs
            headers.setContentDisposition(ContentDisposition.builder("attachment")
                .filename(course.getName() + ".pdf") // Usar el nombre del curso para el archivo
                .build());
            return new ResponseEntity<>(course.getFile(), headers, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}
