package com.hutchinsonports.application.demo.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hutchinsonports.application.demo.app.domain.Course;

@Repository
public interface CurseRepository extends JpaRepository<Course, Long> {

	boolean existsByName(String name);

}
