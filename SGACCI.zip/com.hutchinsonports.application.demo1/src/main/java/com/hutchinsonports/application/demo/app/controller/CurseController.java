package com.hutchinsonports.application.demo.app.controller;

import com.hutchinsonports.application.demo.app.domain.Course;
import com.hutchinsonports.application.demo.app.domain.User;
import com.hutchinsonports.application.demo.app.service.CoursService;
import com.hutchinsonports.application.demo.app.service.UserService;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.ByteArrayInputStream;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class CurseController {

    @Autowired
    private CoursService courseService;

    @Autowired
    private UserService userService;

    @GetMapping("/cours")
    public String listCourses(Model model,
                              @RequestParam(value = "page", defaultValue = "0") int page,
                              @RequestParam(value = "size", defaultValue = "5") int size) {
        Page<Course> coursePage = courseService.findAll(PageRequest.of(page, size));
        model.addAttribute("coursePage", coursePage);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", coursePage.getTotalPages());

        // Obtener el nombre del usuario actual
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }
        model.addAttribute("username", username);

        return "cours";
    }

    @GetMapping("/registerCurse")
    public String showAddCourseForm(Model model) {
        Course cours =new Course();
        List<User> users = userService.findAll();
        
        // Obtener el nombre del usuario autenticado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }

        // Establecer el nombre del usuario autenticado y la fecha actual
        cours.setCreateUsers(username);
        cours.setUpdateUsers(username);
        cours.setCreateAt(LocalDateTime.now());
        cours.setUpdateAt(LocalDateTime.now());
        model.addAttribute("users", users);
        model.addAttribute("course", cours);
        return "registerCurse";
    }

    @PostMapping("/registerCurse")
    public String registerCourse(@Valid @ModelAttribute("course") Course course,
                                 BindingResult result,
                                 RedirectAttributes redirectAttributes,
                                 Model model) {
        // Verificar si ya existe un curso con el mismo nombre
        if (courseService.existsByName(course.getName())) {
            redirectAttributes.addFlashAttribute("errorMessage", "El curso ya existe.");
            model.addAttribute("users", userService.findAll()); // Asegura que los usuarios estén en el modelo
            return "registerCurse";
        }

        if (result.hasErrors()) {
            model.addAttribute("users", userService.findAll()); // Añade los usuarios al modelo en caso de error
            return "registerCurse"; // En caso de error, mostrar de nuevo el formulario
        }

        // Asociar el usuario al curso
        User user = userService.findById(course.getUser().getId()).orElse(null);
        if (user == null) {
            result.rejectValue("user", "error.course", "Usuario no encontrado");
            model.addAttribute("users", userService.findAll());
            return "registerCurse";
        }
        course.setUser(user);
        courseService.save(course);

        redirectAttributes.addFlashAttribute("successMessage", "Curso registrado con éxito");
        return "redirect:/cours";
    }


    @GetMapping("/editCours")
    public String showEditForm(@RequestParam("id") Long id,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        Course course = courseService.findById(id).orElse(null);
        if (course != null) {
        	
            // Obtener el nombre del usuario autenticado
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = null;
            if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
                UserDetails userDetails = (UserDetails) authentication.getPrincipal();
                username = userDetails.getUsername();
            }
            course.setUpdateUsers(username);
            course.setUpdateAt(LocalDateTime.now());
            model.addAttribute("course", course);
            model.addAttribute("users", userService.findAll());
            return "editCours";
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Curso no encontrado");
            return "redirect:/cours";
        }
    }

    @PostMapping("/editCours")
    public String updateCourse(@Valid @ModelAttribute("course") Course course,
                               BindingResult result,
                               RedirectAttributes redirectAttributes,
                               Model model) {
        if (result.hasErrors()) {
            model.addAttribute("users", userService.findAll());
            return "editCours";
        }

        if (course.getId() == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "El ID del curso no puede ser nulo.");
            return "redirect:/editCours";
        }

        // Asociar el usuario al curso
        User user = userService.findById(course.getUser().getId()).orElse(null);
        if (user == null) {
            result.rejectValue("user", "error.course", "Usuario no encontrado");
            model.addAttribute("users", userService.findAll());
            return "editCours";
        }

        // Asignar campos de actualización
        course.setUser(user);
        course.setUpdateAt(LocalDateTime.now());  // Asignar la fecha y hora actuales
        course.setUpdateUsers(SecurityContextHolder.getContext().getAuthentication().getName());  // Asignar el nombre del usuario autenticado

        // Guardar curso actualizado
        courseService.save(course);

        redirectAttributes.addFlashAttribute("successMessage", "Curso actualizado con éxito");
        return "redirect:/cours";
    }

    

    @GetMapping("/pdf/{id}")
    public ResponseEntity<InputStreamResource> generatePdf(@PathVariable Long id) {
        ByteArrayInputStream bis = courseService.generatePdf(id);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=course_" + id + ".pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
}
