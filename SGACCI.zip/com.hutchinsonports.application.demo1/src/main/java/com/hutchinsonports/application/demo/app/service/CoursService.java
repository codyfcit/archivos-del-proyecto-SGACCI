package com.hutchinsonports.application.demo.app.service;

import com.hutchinsonports.application.demo.app.domain.Course;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Optional;

public interface CoursService {

    List<Course> findAll();
    Optional<Course> findById(Long id);
    Course save(Course course);
    void delete(Long id);
    Page<Course> findAll(Pageable pageable);
    ByteArrayInputStream generatePdf(Long id);
	boolean existsByName(String name);



}
