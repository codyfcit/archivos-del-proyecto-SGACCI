package com.hutchinsonports.application.demo.app.config;

import java.io.IOException;

import org.springframework.core.convert.converter.Converter;
import org.springframework.web.multipart.MultipartFile;

public class MultipartFileToByteArrayConverter implements Converter<MultipartFile, byte[]> {

    @Override
    public byte[] convert(MultipartFile source) {
        try {
            return source.getBytes();
        } catch (IOException e) {
            throw new RuntimeException("Error al convertir MultipartFile a byte[]", e);
        }
    }
}

/*La clase MultipartFileToByteArrayConverter implementa la interfaz Converter de Spring
 y se utiliza para convertir un objeto MultipartFile a un array de bytes (byte[]). 
Esta clase es otra manera de manejar la conversión de archivos subidos en formularios 
web en aplicaciones Spring.*/