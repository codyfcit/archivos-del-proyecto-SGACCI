package com.hutchinsonports.application.demo.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.hutchinsonports.application.demo.app.service.UserService;

import jakarta.annotation.PostConstruct;

@Component
public class PasswordUpdater {

    @Autowired
    private UserService userService;

    @PostConstruct
    public void init() {
        userService.updatePasswords();
    }
}
