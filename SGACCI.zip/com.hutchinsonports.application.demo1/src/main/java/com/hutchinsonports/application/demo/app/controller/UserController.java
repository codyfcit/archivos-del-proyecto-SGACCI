
package com.hutchinsonports.application.demo.app.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.hutchinsonports.application.demo.app.domain.User;
import com.hutchinsonports.application.demo.app.domain.Department;
import com.hutchinsonports.application.demo.app.domain.Role;
import com.hutchinsonports.application.demo.app.service.UserService;
import com.hutchinsonports.application.demo.app.service.DepartmentService;
import com.hutchinsonports.application.demo.app.service.RoleService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Ver lista de usuarios
    @GetMapping("/users")
    public String listUsers(Model model,
                            @RequestParam(defaultValue = "0") int page,
                            @RequestParam(defaultValue = "5") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<User> users = userService.findAll(pageable);
        model.addAttribute("users", users.getContent());
        model.addAttribute("totalPages", users.getTotalPages());
        model.addAttribute("currentPage", page);

        // Obtener el nombre del usuario actual
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }
        model.addAttribute("username", username);

        return "users";
    }

    // Mostrar formulario para agregar un nuevo usuario
    @GetMapping("/registerUser")
    public String showAddUserForm(Model model) {
        User user = new User();
        List<Department> departments = departmentService.findAll();
        List<Role> roles = roleService.findAll();

        // Obtener el nombre del usuario autenticado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }

        // Establecer el nombre del usuario autenticado y la fecha actual
        user.setCreateUsers(username);
        user.setUpdateUsers(username);
        user.setCreateAt(LocalDateTime.now());
        user.setUpdateAt(LocalDateTime.now());

        model.addAttribute("user", user);
        model.addAttribute("departments", departments);
        model.addAttribute("roles", roles);
        return "registerUser";
    }

    @PostMapping("/registerUser")
    public String registerUser(@Valid @ModelAttribute("user") User user,
                               @RequestParam(value = "roleId", required = false) Long roleId,
                               BindingResult result,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        // Verificar si hay errores en el formulario
        if (result.hasErrors()) {
            System.out.println(result.getAllErrors());
            model.addAttribute("departments", departmentService.findAll());
            model.addAttribute("roles", roleService.findAll());
            return "registerUser";
        }

        // Verificar si el nombre de usuario ya está en uso
        if (userService.existsByUsersName(user.getUsersName())) {
            result.rejectValue("usersName", "error.user", "El nombre de usuario ya está en uso");
        }

        // Verificar si el correo electrónico ya está en uso
        if (userService.existsByEmail(user.getEmail())) {
            result.rejectValue("email", "error.user", "El correo electrónico ya está en uso");
        }

        // Verificar si el nombre completo ya está en uso
        if (userService.existsByFullName(user.getFullName())) {
            result.rejectValue("fullName", "error.user", "El nombre completo ya está en uso");
        }

        // Verificar si el parámetro roleId es nulo o inválido
        if (roleId == null) {
            model.addAttribute("errorMessage", "El parámetro 'roleId' es requerido.");
        } else {
            Role role = roleService.findById(roleId);
            if (role == null) {
                model.addAttribute("errorMessage", "El rol especificado no existe.");
            } else {
                user.getRoles().add(role);
            }
        }

        // Volver a mostrar el formulario si hay errores de validación
        if (result.hasErrors() || model.containsAttribute("errorMessage")) {
            model.addAttribute("departments", departmentService.findAll());
            model.addAttribute("roles", roleService.findAll());
            return "registerUser";
        }

        // Codificar la contraseña antes de guardar el usuario
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Guardar el usuario
        userService.save(user);

        // Redirigir a la página de usuarios con un mensaje de éxito
        redirectAttributes.addFlashAttribute("successMessage", "El usuario ha sido registrado correctamente");
        return "redirect:/users";
    }


    // Mostrar formulario para editar un usuario
    @GetMapping("/editUsers")
    public String showEditUserForm(@RequestParam("id") Long id, Model model, RedirectAttributes redirectAttributes) {
        User user = userService.findById(id).orElse(null);
        if (user != null) {
            List<Department> departments = departmentService.findAll();
            List<Role> roles = roleService.findAll();

            // Obtener el nombre del usuario autenticado
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = null;
            if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
                UserDetails userDetails = (UserDetails) authentication.getPrincipal();
                username = userDetails.getUsername();
            }
            user.setUpdateUsers(username);
            user.setUpdateAt(LocalDateTime.now());

            model.addAttribute("user", user);
            model.addAttribute("departments", departments);
            model.addAttribute("roles", roleService.findAll());
            return "editUsers";
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Usuario no encontrado");
            return "redirect:/users";
        }
    }

    // Actualizar usuario
    @PostMapping("/editUsers")
    public String updateUser(@Valid @ModelAttribute("user") User user, BindingResult result,
                             @RequestParam("roleId") Long roleId, Model model, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("departments", departmentService.findAll());
            model.addAttribute("roles", roleService.findAll());
            return "editUsers";
        }

        if (user.getId() == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "El ID del usuario no puede ser nulo.");
            return "redirect:/users";
        }

        Role role = roleService.findById(roleId);
        if (role != null) {
            user.getRoles().add(role);
        }

        User usuarioActualizado = userService.findById(user.getId()).orElse(null);
        if (usuarioActualizado != null) {
            usuarioActualizado.setUsersName(user.getUsersName());

            // Actualizar la contraseña solo si se ha proporcionado una nueva
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                usuarioActualizado.setPassword(user.getPassword());
            }

            usuarioActualizado.setEmail(user.getEmail());
            usuarioActualizado.setFullName(user.getFullName());
            usuarioActualizado.setStatus(user.getStatus());
            usuarioActualizado.setUpdateAt(LocalDateTime.now());
            usuarioActualizado.setUpdateUsers(SecurityContextHolder.getContext().getAuthentication().getName());
            usuarioActualizado.setDepartment(user.getDepartment());
            usuarioActualizado.setRoles(user.getRoles());

            userService.save(usuarioActualizado);
            redirectAttributes.addFlashAttribute("successMessage", "Usuario actualizado con éxito");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "No se encontró el usuario a actualizar");
        }

        return "redirect:/users";
    }

    // Eliminar usuario
    @PostMapping("/deleteUsers")
    public String deleteUser(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        User user = userService.findById(id).orElse(null);
        if (user != null) {
            userService.deleteUser(user);
            redirectAttributes.addFlashAttribute("successMessage", "El usuario ha sido eliminado correctamente");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "El usuario no ha sido encontrado");
        }
        return "redirect:/users";
    }
}
