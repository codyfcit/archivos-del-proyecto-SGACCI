package com.hutchinsonports.application.demo.app.service;

import com.hutchinsonports.application.demo.app.domain.Course;
import com.hutchinsonports.application.demo.app.repository.CurseRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import java.util.List;

@Service
public class CurseServiceImpl implements CoursService {

    @Autowired
    private CurseRepository courseRepository;
    
    private static final Logger logger = LoggerFactory.getLogger(CurseServiceImpl.class);

    @Override
    public List<Course> findAll() {
        return courseRepository.findAll();
    }

    @Override
    public Optional<Course> findById(Long id) {
        return courseRepository.findById(id);
    }

    @Override
    public Course save(Course course) {
        return courseRepository.save(course);
    }

    @Override
    public void delete(Long id) {
        courseRepository.deleteById(id);
    }
    
    @Override
    public Page<Course> findAll(Pageable pageable) {
        return courseRepository.findAll(pageable);
    }



    public ByteArrayInputStream generatePdf(Long id) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Agregar el logo
            try {
                InputStream logoStream = getClass().getResourceAsStream("/static/images/descarga.png");
                if (logoStream != null) {
                    byte[] logoBytes = logoStream.readAllBytes();
                    Image logo = Image.getInstance(logoBytes);
                    logo.scaleToFit(100, 50);
                    logo.setAlignment(Element.ALIGN_LEFT);
                    document.add(logo);
                    logoStream.close();
                } else {
                    logger.error("Logo no encontrado en la ruta especificada.");
                }
            } catch (IOException ex) {
                logger.error("Error al cargar el logo: ", ex);
            }

            // Agregar un espacio después del logo
            document.add(new Paragraph(" "));

            // Crear una tabla para el contenido con colores personalizados
            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            table.setSpacingAfter(10f);

            // Crear una fuente con color blanco para los encabezados
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.WHITE);

            // Encabezados de la tabla con colores personalizados
            PdfPCell header1 = new PdfPCell(new Phrase("Campo", headerFont));
            header1.setBackgroundColor(new BaseColor(0x00, 0x2E, 0x6D)); // Color: 002E6D
            header1.setHorizontalAlignment(Element.ALIGN_CENTER);
            header1.setPadding(10);
            header1.setBorderWidth(1f); // Borde negro de 1px
            header1.setBorderColor(BaseColor.BLACK);
            table.addCell(header1);

            PdfPCell header2 = new PdfPCell(new Phrase("Valor", headerFont));
            header2.setBackgroundColor(new BaseColor(0x00, 0x2E, 0x6D)); // Color: 002E6D
            header2.setHorizontalAlignment(Element.ALIGN_CENTER);
            header2.setPadding(10);
            header2.setBorderWidth(1f); // Borde negro de 1px
            header2.setBorderColor(BaseColor.BLACK);
            table.addCell(header2);

         // Obtener los datos del curso
            Optional<Course> courseOpt = findById(id);
            if (courseOpt.isPresent()) {
                Course course = courseOpt.get();

                // Agregar filas a la tabla con colores personalizados
                addTableCell(table, "Nombre del curso", course.getName(), BaseColor.WHITE); // Color: FFFFFF
                addTableCell(table, "Descripción", course.getDescription(), BaseColor.WHITE); // Color: FFFFFF

                // Manejo de fechas con valores por defecto si son nulos
                String dateString = (course.getDate() != null) ? course.getDate().toString() : "Fecha no disponible";
                addTableCell(table, "Fecha", dateString, BaseColor.WHITE); // Color: FFFFFF

                addTableCell(table, "Estado", course.getStatus(), BaseColor.WHITE); // Color: FFFFFF

                String createAtString = (course.getCreateAt() != null) ? course.getCreateAt().toString() : "Fecha no disponible";
                addTableCell(table, "Fecha de creación", createAtString, BaseColor.WHITE); // Color: FFFFFF

                addTableCell(table, "Usuario creador", course.getCreateUsers() != null ? course.getCreateUsers() : "Usuario no disponible", BaseColor.WHITE); // Color: FFFFFF

                String updateAtString = (course.getUpdateAt() != null) ? course.getUpdateAt().toString() : "Fecha no disponible";
                addTableCell(table, "Fecha de actualización", updateAtString, BaseColor.WHITE); // Color: FFFFFF

                addTableCell(table, "Usuario actualizador", course.getUpdateUsers() != null ? course.getUpdateUsers() : "Usuario no disponible", BaseColor.WHITE); // Color: FFFFFF
            } else {
                addTableCell(table, "Error", "Curso no encontrado", BaseColor.RED); // Color: rojo para indicar error
            }


            document.add(table);
            document.close();
        } catch (DocumentException ex) {
            logger.error("Error al generar el PDF: ", ex);
        }

        return new ByteArrayInputStream(out.toByteArray());
    }


    private void addTableCell(PdfPTable table, String field, String value, BaseColor valueColor) {
        PdfPCell cellField = new PdfPCell(new Phrase(field));
        cellField.setBackgroundColor(BaseColor.LIGHT_GRAY); // Color: 264B81
        cellField.setPadding(5);
        cellField.setBorderWidth(1f); // Borde negro de 1px
        cellField.setBorderColor(BaseColor.BLACK);
        table.addCell(cellField);

        PdfPCell cellValue = new PdfPCell(new Phrase(value));
        cellValue.setBackgroundColor(valueColor);
        cellValue.setPadding(5);
        cellValue.setBorderWidth(1f); // Borde negro de 1px
        cellValue.setBorderColor(BaseColor.BLACK);
        table.addCell(cellValue);
    }
    
    public boolean existsByName(String name) {
        return courseRepository.existsByName(name);
    }

    }