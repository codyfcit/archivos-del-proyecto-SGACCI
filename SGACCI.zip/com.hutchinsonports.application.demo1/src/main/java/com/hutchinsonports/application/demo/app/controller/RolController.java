package com.hutchinsonports.application.demo.app.controller;

import com.hutchinsonports.application.demo.app.domain.Role;
import com.hutchinsonports.application.demo.app.service.RoleService;
import com.hutchinsonports.application.demo.app.service.UserService;

import jakarta.validation.Valid;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

@Controller
public class RolController {

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserService userService;

    // Ver lista de roles
    @GetMapping("/roles")
    public String listRoles(Model model,
                            @RequestParam(name = "page", defaultValue = "0") int page,
                            @RequestParam(name = "size", defaultValue = "5") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Role> rolePage = roleService.findAll(pageable);
        
        model.addAttribute("roles", rolePage.getContent());
        model.addAttribute("totalPages", rolePage.getTotalPages());
        model.addAttribute("currentPage", page);
        // Obtener el nombre del usuario actual
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }
        model.addAttribute("username", username);
        
        return "roles";
    }

    // Mostrar formulario para agregar un nuevo rol
    @GetMapping("/registerRole")
    public String showAddRoleForm(Model model) {
    	Role role = new Role();
    	
        // Obtener el nombre del usuario autenticado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = null;
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            username = userDetails.getUsername();
        }
        
        // Asignar el nombre del usuario autenticado al campo 'createUsers'
        role.setCreateUsers(username);
        role.setUpdateUsers(username);
        // Establecer la fecha y hora actuales en los campos 'createAt' y 'updateAt'
        role.setCreateAt(LocalDateTime.now());
        role.setUpdateAt(LocalDateTime.now());
        
        // Agregar el objeto 'role' al modelo
        model.addAttribute("role", role);
        return "registerRole";
    }
    @PostMapping("/registerRole")
    public String registerRole(@Valid @ModelAttribute("role") Role role,
                               BindingResult result,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        // Verificar si ya existe un rol con el mismo nombre
        if (roleService.existsByrolName(role.getRolName())) {
            redirectAttributes.addFlashAttribute("errorMessage", "El rol ya existe.");
            return "redirect:/registerRole";
        }

        // Verificar si hay errores en el formulario
        if (result.hasErrors()) {
            return "registerRole"; // En caso de error, mostrar de nuevo el formulario
        }

        // Guardar el rol
        roleService.save(role);

        // Redirigir a la página de roles con un mensaje de éxito
        redirectAttributes.addFlashAttribute("successMessage", "Rol registrado con éxito");
        return "redirect:/roles";
    }


    // Mostrar formulario para editar un rol
    @GetMapping("/editRoles")
    public String EditForm(@RequestParam("id") Long id, Model model, RedirectAttributes redirectAttributes) {
        Role role = roleService.findById(id).orElse(null);
        if (role != null) {
            model.addAttribute("role", role);
            return "editRoles"; 
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Rol no encontrado");
            return "redirect:/editroles";
        }
    }


    // Editar rol
    @PostMapping("/editRoles")
    public String updateRole(@Valid @ModelAttribute("role") Role role, BindingResult result, Model model, RedirectAttributes redirectAttributes) {
        // Verificar si hay errores en la validación
        if (result.hasErrors()) {
            // Cargar la lista de usuarios para el formulario
            model.addAttribute("users", userService.findAll());
            return "/editRoles"; // Mostrar de nuevo el formulario en caso de error
        }

        // Verificar si el ID del rol es nulo
        if (role.getId() == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "El ID del rol no puede ser nulo.");
            return "redirect:/roles";
        }

        // Buscar el rol en la base de datos
        Role existingRole = roleService.findById(role.getId()).orElse(null);
        if (existingRole != null) {
            // Actualizar los campos del rol
            existingRole.setRolName(role.getRolName());
            existingRole.setDescription(role.getDescription());
            existingRole.setCreateAt(role.getCreateAt());
            existingRole.setCreateUsers(role.getCreateUsers());
            existingRole.setUpdateAt(role.getUpdateAt());
            existingRole.setUpdateUsers(role.getUpdateUsers());

            // Guardar los cambios en la base de datos
            roleService.save(existingRole);
            redirectAttributes.addFlashAttribute("successMessage", "Rol actualizado con éxito");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "No se encontró el rol a actualizar");
        }

        return "redirect:/roles";
    }

    // Eliminar rol
    @PostMapping("/deleteRole")
    public String deleteRole(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        Role role = roleService.findById(id).orElse(null);
        if (role != null) {
            roleService.delete(id);
            redirectAttributes.addFlashAttribute("successMessage", "Rol eliminado con éxito");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Rol no encontrado");
        }
        return "redirect:/roles";
    }
}
