package com.hutchinsonports.application.demo.app.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "roles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty(message = "El nombre del rol es obligatorio.")
    @Size(max = 45, message = "El nombre del rol debe tener un máximo de 45 caracteres.")
    @Column(name = "rol_name", length = 45, nullable = false)
    private String rolName;

    @NotEmpty(message = "El campo no puede quedar vacio.")
    @Size(max = 200, message = "La descripción debe tener un máximo de 200 caracteres.")
    @Column(name = "description", length = 200)
    private String description;

    @Column(name = "create_at", nullable = false)
    private LocalDateTime createAt;


    @Column(name = "create_users", length = 45, nullable = false)
    private String createUsers;

    @Column(name = "update_at")
    private LocalDateTime updateAt;

    @Column(name = "update_users", length = 45)
    private String updateUsers;
    

    @ManyToMany(mappedBy = "roles")
    private Set<User> users = new HashSet<>();


    // Constructor parametrizado
    public Role(String rolName, String description, LocalDateTime createAt, String createUsers, LocalDateTime updateAt, String updateUsers) {
        this.rolName = rolName;
        this.description = description;
        this.createAt = createAt;
        this.createUsers = createUsers;
        this.updateAt = updateAt;
        this.updateUsers = updateUsers;
    }

    public Role() {}

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRolName() {
        return rolName;
    }

    public void setRolName(String rolName) {
        this.rolName = rolName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreateAt() {
        return createAt;
    }

    public void setCreateAt(LocalDateTime createAt) {
        this.createAt = createAt;
    }

    public String getCreateUsers() {
        return createUsers;
    }

    public void setCreateUsers(String createUsers) {
        this.createUsers = createUsers;
    }

    public LocalDateTime getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(LocalDateTime updateAt) {
        this.updateAt = updateAt;
    }

    public String getUpdateUsers() {
        return updateUsers;
    }

    public void setUpdateUsers(String updateUsers) {
        this.updateUsers = updateUsers;
    }

    public Set<User> getUsers() {
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }

    public void addUser(User user) {
        this.users.add(user);
        user.getRoles().add(this);
    }

    public void removeUser(User user) {
        this.users.remove(user);
        user.getRoles().remove(this);
    }

	public Role orElse(Object object) {
		// TODO Auto-generated method stub
		return null;
	}
}
